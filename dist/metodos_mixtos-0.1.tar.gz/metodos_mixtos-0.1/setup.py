# setup.py

from setuptools import setup, find_packages

setup(
    name='metodos_mixtos',
    version='0.1',
    packages=find_packages(),
    description='Paquete the Python para Métodos Mixtos Conslutores',
    author='Daniel Wiesner',
    author_email='dwiesner@metodosmixtos.com',
    url='https://github.com/Metodos-Mixtos/metodos-mixtos',
)
